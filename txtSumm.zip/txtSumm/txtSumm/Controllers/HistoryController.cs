﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using txtSumm.Context;
using txtSumm.Models;
using txtSumm.Models.Dto;

namespace txtSumm.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class HistoryController : ControllerBase
	{
		private readonly AppDbContext _context;
		public HistoryController(AppDbContext appDbContext)
		{
			_context = appDbContext;
		}


		[HttpPost("addtext")]
		public async Task<IActionResult> AddText([FromBody] addTextDto historyDto)
		{
			History history = new History();
			history.Text = historyDto.Text;
			history.TextSummary = historyDto.TextSummary;
			User user = await _context.Users.FirstOrDefaultAsync(e => e.Email == historyDto.Email);
			int userId = user.Id;
			history.UserId = userId;
			await _context.History.AddAsync(history);
			await _context.SaveChangesAsync();

			return Ok();
		}

		[HttpGet("gethistory")]
		public async Task<ActionResult<IEnumerable<History>>> GetHistory(string email)
		{
			User user = await _context.Users.FirstOrDefaultAsync(e => e.Email == email);
			if (user == null)
				return NotFound(new
				{
					Message = "Email Not Found!"
				});
			int userId = user.Id;
			var history = await _context.History.Where(e => e.UserId == userId).Select(x => new { x.Text, x.TextSummary }).ToListAsync();

			return Ok(history);
		}
	}
}