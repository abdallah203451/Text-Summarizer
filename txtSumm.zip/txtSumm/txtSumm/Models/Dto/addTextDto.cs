﻿namespace txtSumm.Models.Dto
{
	public class addTextDto
	{
		public string Text { get; set; }
		public string TextSummary { get; set; }
		public string Email { get; set; }
	}
}
